import type { Rule } from "eslint";
export declare const noComments: Rule.RuleModule;
