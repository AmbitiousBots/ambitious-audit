export declare const COMMENT_BUDGET = 10;
export declare const BUDGET_COMMENT: RegExp;
export declare const countBudgetComments: (root: string, ignores: readonly string[]) => number;
