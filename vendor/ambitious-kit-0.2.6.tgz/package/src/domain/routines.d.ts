import { type Fingerprint, type TextMatch } from "./whitespace.ts";
export type EarlierPrompt = {
    readonly template: string;
    readonly whitespaceSha256: string;
};
export type TemplateRoutine = Fingerprint & {
    readonly name: string;
    readonly schedule: string;
    readonly paused: boolean;
    readonly prompt: string;
    readonly earlier: readonly EarlierPrompt[];
};
export type BotRoutine = Fingerprint & {
    readonly name: string;
    readonly schedule: string;
};
export type RoutineOffer = {
    readonly name: string;
    readonly schedule: string;
    readonly prompt: string;
};
export type RoutineProblem = "routine-prompt-out-of-date" | "routine-missing" | "routine-custom";
type Proposal = {
    readonly name: string;
    readonly starts: "active" | "paused";
    readonly schedule: {
        readonly current: string | null;
        readonly template: string;
    };
    readonly prompt: string;
};
export type RoutineFinding = Proposal & ({
    readonly state: "current";
    readonly problem: null;
    readonly match: TextMatch;
    readonly publishedIn: null;
} | {
    readonly state: "out-of-date";
    readonly problem: "routine-prompt-out-of-date";
    readonly match: "whitespace";
    readonly publishedIn: string;
} | {
    readonly state: "missing";
    readonly problem: "routine-missing";
    readonly match: null;
    readonly publishedIn: null;
} | {
    readonly state: "custom";
    readonly problem: "routine-custom";
    readonly match: null;
    readonly publishedIn: null;
});
export declare const ROUTINES_HINT = "Write the bot's current routines to a JSON file outside the bot's private data directory and name that file with --routines. It holds a list of { \"name\", \"schedule\", \"prompt\" }, one entry for each routine this bot has now: its name, its schedule as the platform shows it, and its prompt copied exactly.";
export declare const classifyRoutine: (template: TemplateRoutine, mine: readonly BotRoutine[]) => RoutineFinding;
export declare const routineMessage: (finding: RoutineFinding, proposed: string) => string | null;
export declare const parseRoutineOffers: (value: unknown) => readonly RoutineOffer[];
export declare const parseTemplateRoutines: (value: unknown) => readonly TemplateRoutine[];
export {};
