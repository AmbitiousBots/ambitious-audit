import { isRecord } from "./json.js";
import { matchOf } from "./whitespace.js";
export const ADDITIONAL_PERMISSIONS = "Pasting this text gives the bot these additional permissions:";
const VERSION_LINE = /^Instructions version: ([1-9][0-9]*)(?:\n|$)/;
const SHA256 = /^[0-9a-f]{64}$/;
export const instructionsVersionOf = (folded) => {
    const declared = VERSION_LINE.exec(folded)?.[1];
    return declared === undefined ? null : Number(declared);
};
export const classifyInstructions = (folded, given, { version: template, known }) => {
    if (folded === "")
        return { state: "out-of-date", problem: "instructions-out-of-date", current: null, template, match: null };
    const exact = known.find((entry) => entry.sha256 === given.sha256);
    const published = exact ?? known.find((entry) => matchOf(given, entry) !== null);
    if (published !== undefined) {
        const match = exact === undefined ? "whitespace" : "exact";
        return published.version === template
            ? { state: "current", problem: null, current: template, template, match }
            : { state: "out-of-date", problem: "instructions-out-of-date", current: published.version, template, match };
    }
    const declared = instructionsVersionOf(folded);
    if (declared !== null && declared > template)
        return { state: "newer", problem: null, current: declared, template, match: null };
    return { state: "custom", problem: "instructions-custom", current: declared, template, match: null };
};
export const needsOwner = (finding) => finding.state === "out-of-date" || (finding.state === "custom" && finding.current !== finding.template);
const numbered = (permissions) => permissions.map(({ permission }, index) => `(${index + 1}) ${permission}`).join(" ");
const statementOf = (comparedWith, added, removed) => {
    const basis = comparedWith === "the bot's present text"
        ? ""
        : "This bot's present instructions are not a text this template published, so what they allow cannot be compared; the comparison is with the oldest instructions text still supported. ";
    const takesAway = removed.length === 0 ? "" : ` It takes away these permissions: ${numbered(removed)}`;
    if (added.length > 0)
        return `${basis}${ADDITIONAL_PERMISSIONS} ${numbered(added)}${takesAway}`;
    if (removed.length > 0)
        return `${basis}Pasting this text gives the bot no additional permissions.${takesAway}`;
    return `${basis}Pasting this text gives the bot no additional permissions and takes none away: it allows the same things as ${comparedWith}.`;
};
export const permissionChange = (finding, { version, oldestSupported, grants, versions }) => {
    if (finding.state === "newer")
        return null;
    const published = finding.match === null ? undefined : versions.find((entry) => entry.version === finding.current);
    const basis = published ?? versions.find((entry) => entry.version === oldestSupported);
    const proposed = versions.find((entry) => entry.version === version);
    if (basis === undefined || proposed === undefined)
        return null;
    const described = (names, reasons) => names.map((grant) => ({ grant, permission: grants[grant] ?? grant, reason: reasons[grant] ?? null }));
    const added = described(proposed.grants.filter((grant) => !basis.grants.includes(grant)), proposed.reasons);
    const removed = described(basis.grants.filter((grant) => !proposed.grants.includes(grant)), {});
    const comparedWith = published === undefined ? "the oldest supported text" : "the bot's present text";
    const comparison = added.length > 0 ? (removed.length > 0 ? "more and fewer" : "more") : removed.length > 0 ? "fewer" : "same";
    return { comparedWith, comparison, added, removed, statement: statementOf(comparedWith, added, removed) };
};
export const instructionsMessage = (finding, proposed, change) => {
    const { current, template } = finding;
    const unchanged = "Nothing was changed: only the owner can replace a bot's instructions, and doing so is the owner's choice.";
    const permissions = change === null ? "" : ` ${change.statement}`;
    if (finding.state === "out-of-date") {
        const have = current === null ? "have no text" : `are version ${current}`;
        return `instructions-out-of-date: This bot's instructions ${have} and this template's are version ${template}. The template's text is in ${proposed}. ${unchanged}${permissions}`;
    }
    if (finding.state === "custom") {
        if (current === template) {
            return `instructions-custom: This bot's instructions say version ${template}, the template's version, but their text is not the template's. They were left as they are.`;
        }
        const have = current === null ? "carry no version line" : `say version ${current}`;
        return `instructions-custom: This bot's instructions are not a text this template published; they ${have}, and this template's are version ${template}. The template's text is in ${proposed}. They were left as they are, so that nothing the owner wrote is lost. ${unchanged}${permissions}`;
    }
    if (finding.state === "newer") {
        return `This bot's instructions say version ${current}, which is newer than version ${template} that this installer knows. They were left as they are. Update the bot's skills to the template those instructions came from.`;
    }
    return null;
};
export const lineDiff = (from, to) => {
    const linesOf = (text) => (text === "" ? [] : text.replace(/\n$/, "").split("\n"));
    const [before, after] = [linesOf(from), linesOf(to)];
    const width = after.length + 1;
    const common = new Uint32Array((before.length + 1) * width);
    for (let i = before.length - 1; i >= 0; i -= 1) {
        for (let j = after.length - 1; j >= 0; j -= 1) {
            common[i * width + j] = before[i] === after[j] ? (common[(i + 1) * width + j + 1] ?? 0) + 1 : Math.max(common[(i + 1) * width + j] ?? 0, common[i * width + j + 1] ?? 0);
        }
    }
    const changes = [];
    let [i, j] = [0, 0];
    while (i < before.length || j < after.length) {
        if (i < before.length && j < after.length && before[i] === after[j]) {
            i += 1;
            j += 1;
        }
        else if (j >= after.length || (i < before.length && (common[(i + 1) * width + j] ?? 0) >= (common[i * width + j + 1] ?? 0))) {
            changes.push(`- ${before[i] ?? ""}`);
            i += 1;
        }
        else {
            changes.push(`+ ${after[j] ?? ""}`);
            j += 1;
        }
    }
    return changes;
};
export const parseInstructionsCatalogue = (value) => {
    const wrong = (what) => {
        throw new Error(`The embedded instructions catalogue ${what}.`);
    };
    const isVersion = (candidate, highest) => typeof candidate === "number" && Number.isInteger(candidate) && candidate >= 1 && candidate <= highest;
    const isHash = (candidate) => typeof candidate === "string" && SHA256.test(candidate);
    const isNames = (candidate) => Array.isArray(candidate) && candidate.every((name) => typeof name === "string");
    const texts = (candidate, what) => {
        if (!isRecord(candidate))
            return wrong(`needs ${what} as an object of name to text`);
        return Object.fromEntries(Object.entries(candidate).map(([name, text]) => [name, typeof text === "string" && text !== "" ? text : wrong(`needs text for "${name}" in ${what}`)]));
    };
    if (!isRecord(value))
        return wrong("must be an object");
    const { version, oldestSupported, text, known, grants, versions } = value;
    if (!isVersion(version, Number.MAX_SAFE_INTEGER))
        return wrong("needs a whole-number version of 1 or more");
    if (!isVersion(oldestSupported, version))
        return wrong("needs an oldest supported version between 1 and the current one");
    if (typeof text !== "string" || text !== `${text.split("\n").map((line) => line.trimEnd()).join("\n").trim()}\n` || instructionsVersionOf(text) !== version) {
        return wrong(`needs its text to start with "Instructions version: ${version}" and to be free of trailing spaces and blank lines at either end`);
    }
    if (!Array.isArray(known))
        return wrong("needs a list of known texts");
    const entries = known.map((entry) => {
        if (!isRecord(entry) || !isVersion(entry.version, version))
            return wrong("lists a known text without a version between 1 and the current one");
        if (!isHash(entry.sha256) || !isHash(entry.whitespaceSha256))
            return wrong("lists a known text without its two SHA-256 values");
        return { version: entry.version, sha256: entry.sha256, whitespaceSha256: entry.whitespaceSha256 };
    });
    const described = texts(grants, "the grants");
    if (!Array.isArray(versions))
        return wrong("needs a list of versions with their grants");
    const published = versions.map((entry) => {
        if (!isRecord(entry) || !isVersion(entry.version, version))
            return wrong("lists grants for a version that is not between 1 and the current one");
        if (!isNames(entry.grants) || entry.grants.some((grant) => described[grant] === undefined))
            return wrong(`lists a grant for version ${entry.version} that it does not describe`);
        return { version: entry.version, grants: entry.grants, reasons: texts(entry.reasons, `the reasons of version ${entry.version}`) };
    });
    for (const needed of [version, oldestSupported])
        if (!published.some((entry) => entry.version === needed))
            return wrong(`needs the grants of version ${needed}`);
    return { version, oldestSupported, text, known: entries, grants: described, versions: published };
};
