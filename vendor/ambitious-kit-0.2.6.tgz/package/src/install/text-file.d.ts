import { type Fingerprint } from "../domain/whitespace.ts";
export declare const fingerprintOf: (text: string) => Fingerprint;
export declare const textOfFile: (file: string, what: string, hint: string) => string;
