import type { LockRow } from "../domain/lock.ts";
import { type Download } from "./install.ts";
export type ModuleState = "installed" | "unchanged" | "reinstalled" | "upgraded" | "failed";
export type SelfcheckState = "ok" | "problems" | "not run";
export type ModuleReport = {
    readonly module: string;
    readonly version: string;
    readonly state: ModuleState;
    readonly selfcheck: SelfcheckState;
    readonly problems: readonly string[];
};
export type Runtimes = {
    readonly node: string;
    readonly python: () => string | null;
};
export type SyncRequest = {
    readonly rows: readonly LockRow[];
    readonly home: string;
    readonly sourceFor: (row: LockRow) => Download;
    readonly runtimes: Runtimes;
    readonly environment: Readonly<Record<string, string | undefined>>;
};
export declare const findPython: () => string | null;
export declare const sync: (request: SyncRequest) => Promise<readonly ModuleReport[]>;
export declare const summaryOf: (reports: readonly ModuleReport[]) => string;
