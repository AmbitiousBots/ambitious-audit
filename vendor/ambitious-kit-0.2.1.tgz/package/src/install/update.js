import { spawnSync } from "node:child_process";
import { rmSync } from "node:fs";
import { join } from "node:path";
import { Failure } from "../domain/failure.js";
import { isRecord } from "../domain/json.js";
import { isNewerVersion } from "../domain/lock.js";
import { currentLink, install, pointLink } from "./install.js";
import { INSTALLER_MODULE, kitRelease, latestInstallerVersion, networkFetchers, releaseDownload } from "./release.js";
const HANDOVER_TIMEOUT_MS = 900_000;
const LINK = `ambitious-${INSTALLER_MODULE}`;
const reason = (error) => error instanceof Failure ? error.errors.map(({ message }) => message).join(" ") : error instanceof Error ? error.message : String(error);
const answersAsInstaller = (stdout) => {
    try {
        const parsed = JSON.parse(stdout);
        return isRecord(parsed) && parsed.module === INSTALLER_MODULE && typeof parsed.ok === "boolean";
    }
    catch {
        return false;
    }
};
export const updateInstaller = async ({ own, home, mirror, node, environment, fetchers = networkFetchers }) => {
    const keptPins = "The pins that came with this installer were used.";
    const latest = await latestInstallerVersion(mirror, fetchers).catch((error) => new Error(reason(error)));
    if (latest instanceof Error)
        return { kind: "unchecked", problem: `Could not check for a newer template release: ${latest.message}. ${keptPins}` };
    if (latest === null || !isNewerVersion(latest, own))
        return { kind: "current" };
    const bin = join(home, "bin");
    const previous = currentLink(join(bin, LINK));
    try {
        const { path } = await install({ module: INSTALLER_MODULE, version: latest, kind: "mjs", home, download: releaseDownload(kitRelease(latest), mirror, fetchers) });
        const handover = spawnSync(node, [path, "sync", "--json", "--updated-from", own, ...(mirror === null ? [] : ["--from", mirror])], {
            encoding: "utf8",
            timeout: HANDOVER_TIMEOUT_MS,
            env: { ...environment },
        });
        if (answersAsInstaller(handover.stdout))
            return { kind: "handedOver", stdout: handover.stdout, status: handover.status ?? 2 };
        if (previous === null)
            rmSync(join(bin, LINK), { force: true });
        else
            pointLink(bin, LINK, previous);
        return { kind: "unchecked", problem: `The newer template release ${latest} did not run correctly, so it was set aside. ${keptPins}` };
    }
    catch (error) {
        return { kind: "unchecked", problem: `The newer template release ${latest} could not be installed: ${reason(error)} ${keptPins}` };
    }
};
