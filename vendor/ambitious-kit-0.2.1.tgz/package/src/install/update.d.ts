import { type Fetchers } from "./release.ts";
export type UpdateRequest = {
    readonly own: string;
    readonly home: string;
    readonly mirror: string | null;
    readonly node: string;
    readonly environment: Readonly<Record<string, string | undefined>>;
    readonly fetchers?: Fetchers;
};
export type UpdateOutcome = {
    readonly kind: "current";
} | {
    readonly kind: "handedOver";
    readonly stdout: string;
    readonly status: number;
} | {
    readonly kind: "unchecked";
    readonly problem: string;
};
export declare const updateInstaller: ({ own, home, mirror, node, environment, fetchers }: UpdateRequest) => Promise<UpdateOutcome>;
