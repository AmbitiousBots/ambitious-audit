import { type Migration } from "../domain/migrations.ts";
import { type Db } from "./open-db.ts";
export declare const migrate: (db: Db, migrations: readonly Migration[]) => readonly string[];
export declare const requireCurrentSchema: (db: Db, migrations: readonly Migration[]) => void;
export declare const integrityCheck: (db: Db) => string;
