import type { ErrorCode, ErrorEntry } from "./envelope.ts";
import type { JsonObject } from "./json.ts";
export declare class Failure extends Error {
    readonly errors: readonly [ErrorEntry, ...ErrorEntry[]];
    readonly data: JsonObject;
    constructor(errors: readonly [ErrorEntry, ...ErrorEntry[]], data?: JsonObject);
}
export declare const failure: (code: ErrorCode, message: string, hint: string, data?: JsonObject) => Failure;
