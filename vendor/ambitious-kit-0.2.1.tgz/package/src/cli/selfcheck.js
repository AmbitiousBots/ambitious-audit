import { createHash } from "node:crypto";
import { readFileSync, realpathSync } from "node:fs";
import { Failure } from "../domain/failure.js";
import { integrityCheck, migrate } from "../db/migrate.js";
import { openDb, readUserVersion } from "../db/open-db.js";
const NOT_CHECKED = "not checked";
const findingsOf = (error) => {
    if (error instanceof Failure)
        return error.errors.map((entry) => ({ problem: entry.message, error: entry }));
    const detail = error instanceof Error ? error.message : String(error);
    return [
        {
            problem: `The self-check could not finish: ${detail}.`,
            error: { code: "E_INTERNAL", message: "The self-check hit an unexpected error.", hint: "Report it with the stderr log." },
        },
    ];
};
const checkDb = ({ module, dbPath, migrations }) => {
    const unread = { integrityCheck: NOT_CHECKED, userVersion: 0, migrationsApplied: [] };
    let db;
    try {
        db = openDb(dbPath, { readonly: false });
    }
    catch (error) {
        return { ...unread, findings: findingsOf(error) };
    }
    try {
        const migration = (() => {
            try {
                return { applied: migrate(db, migrations), findings: [] };
            }
            catch (error) {
                return { applied: [], findings: findingsOf(error) };
            }
        })();
        const integrity = integrityCheck(db);
        const corrupt = integrity === "ok"
            ? []
            : [
                {
                    problem: `The database failed its integrity check: ${integrity}.`,
                    error: {
                        code: "E_DB",
                        message: "The database failed its integrity check.",
                        hint: `Restore ${module}.sqlite from a backup, then run selfcheck again.`,
                    },
                },
            ];
        return {
            integrityCheck: integrity,
            userVersion: readUserVersion(db),
            migrationsApplied: migration.applied,
            findings: [...migration.findings, ...corrupt],
        };
    }
    catch (error) {
        return { ...unread, findings: findingsOf(error) };
    }
    finally {
        db.close();
    }
};
const binaryReport = (binaryPath) => {
    const path = realpathSync(binaryPath);
    return { path, sha256: createHash("sha256").update(readFileSync(path)).digest("hex") };
};
export const selfcheck = (context) => {
    const { findings, ...db } = checkDb(context);
    const data = {
        runtime: { name: "node", version: process.versions.node },
        binary: binaryReport(context.binaryPath),
        db: { path: context.dbPath, ...db },
        problems: findings.map(({ problem }) => problem),
    };
    const [first, ...rest] = findings.map(({ error }) => error);
    if (first !== undefined)
        throw new Failure([first, ...rest], data);
    return data;
};
