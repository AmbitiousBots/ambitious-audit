export const embedded = () => {
    if (typeof AMBITIOUS_MODULE === "undefined" ||
        typeof AMBITIOUS_VERSION === "undefined" ||
        typeof AMBITIOUS_MIGRATIONS === "undefined") {
        throw new Error("The module name, version and migrations are embedded when the binary is bundled. Build with bundleOptions() from @ambitious/kit/build/bundle-options and run the file in dist/.");
    }
    return { module: AMBITIOUS_MODULE, version: AMBITIOUS_VERSION, migrations: AMBITIOUS_MIGRATIONS };
};
export const embeddedLock = () => {
    if (typeof AMBITIOUS_LOCK === "undefined") {
        throw new Error("The module pins are embedded when the installer is bundled. Run the file in dist/, or name a lock file with --lock.");
    }
    return AMBITIOUS_LOCK;
};
