import { type Envelope } from "../domain/envelope.ts";
import type { Migration } from "../domain/migrations.ts";
import { type Command } from "./command.ts";
export type ModuleSpec = {
    readonly module: string;
    readonly version: string;
    readonly schemaVersion: number;
    readonly migrations: readonly Migration[];
    readonly commands: Readonly<Record<string, Command>>;
};
export type Io = {
    readonly argv: readonly string[];
    readonly env: Readonly<Record<string, string | undefined>>;
    readonly binaryPath: string;
    readonly readStdin: () => Promise<string>;
    readonly systemNow: () => Date;
    readonly systemSeed: () => number;
    readonly writeStdout: (text: string) => void;
    readonly writeStderr: (text: string) => void;
};
export declare const cliEnvelope: (spec: ModuleSpec, io: Io) => Promise<Envelope>;
export declare const runCli: (spec: ModuleSpec) => Promise<void>;
