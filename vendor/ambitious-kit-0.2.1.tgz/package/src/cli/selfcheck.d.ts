import type { JsonObject } from "../domain/json.ts";
import type { Migration } from "../domain/migrations.ts";
export type SelfcheckContext = {
    readonly module: string;
    readonly dbPath: string;
    readonly binaryPath: string;
    readonly migrations: readonly Migration[];
};
export declare const selfcheck: (context: SelfcheckContext) => JsonObject;
